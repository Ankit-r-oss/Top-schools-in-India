import { Badge } from "./ui/badge";
import { Card } from "./ui/card";

interface SchoolData {
  name: string;
  location: string;
  ranking: number;
  type: string;
  established: number;
  board: string;
}

interface SchoolCardProps {
  school: SchoolData;
}

export function SchoolCard({ school }: SchoolCardProps) {
  return (
    <Card className="p-4 bg-card border border-border">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h3 className="text-lg font-medium text-foreground mb-1">{school.name}</h3>
          <p className="text-muted-foreground text-sm">{school.location}</p>
        </div>
        <Badge variant="outline" className="ml-2 bg-primary text-primary-foreground">
          #{school.ranking}
        </Badge>
      </div>
      
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <span className="text-muted-foreground">Type:</span>
          <p className="text-foreground">{school.type}</p>
        </div>
        <div>
          <span className="text-muted-foreground">Board:</span>
          <p className="text-foreground">{school.board}</p>
        </div>
        <div>
          <span className="text-muted-foreground">Established:</span>
          <p className="text-foreground">{school.established}</p>
        </div>
      </div>
    </Card>
  );
}
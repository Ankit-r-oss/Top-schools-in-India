import { Button } from "./ui/button";
import { GraduationCap, Menu, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export function Header() {
  return (
    <header className="bg-white/95 backdrop-blur-sm border-b border-border/50 px-4 py-3 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <motion.div 
          className="flex items-center space-x-3"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* New Modern Logo */}
          <div className="relative">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 via-blue-600 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-pulse">
              <Sparkles className="w-2 h-2 text-white m-0.5" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-xl bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-500 bg-clip-text text-transparent">
              EduMinatti
            </span>
            <span className="text-xs text-muted-foreground -mt-1">Find Your Perfect School</span>
          </div>
        </motion.div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <motion.a 
            href="#" 
            className="text-foreground hover:text-purple-600 transition-all duration-300 relative group"
            whileHover={{ scale: 1.05 }}
          >
            Home
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-600 to-blue-600 group-hover:w-full transition-all duration-300"></span>
          </motion.a>
          
          <motion.a 
            href="#" 
            className="text-muted-foreground hover:text-blue-600 transition-all duration-300 relative group"
            whileHover={{ scale: 1.05 }}
          >
            About
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-blue-600 to-emerald-500 group-hover:w-full transition-all duration-300"></span>
          </motion.a>
          
          <Button 
            variant="outline" 
            size="sm"
            className="border-purple-200 text-purple-700 hover:bg-purple-50 hover:border-purple-300 transition-all duration-300"
          >
            Compare Schools
          </Button>
          
          <motion.a 
            href="#" 
            className="text-muted-foreground hover:text-emerald-600 transition-all duration-300 relative group"
            whileHover={{ scale: 1.05 }}
          >
            Contact
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-emerald-500 to-blue-500 group-hover:w-full transition-all duration-300"></span>
          </motion.a>
          
          <motion.a 
            href="#" 
            className="text-muted-foreground hover:text-orange-600 transition-all duration-300 relative group"
            whileHover={{ scale: 1.05 }}
          >
            Blogs
            <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-orange-500 to-pink-500 group-hover:w-full transition-all duration-300"></span>
          </motion.a>
          
          <Button 
            size="sm" 
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
          >
            Get Consultation
          </Button>
        </nav>

        {/* Mobile Menu Button */}
        <Button variant="ghost" size="sm" className="md:hidden hover:bg-purple-50">
          <Menu className="w-5 h-5 text-purple-600" />
        </Button>
      </div>
    </header>
  );
}
import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";
import { Slider } from "./ui/slider";
import { Separator } from "./ui/separator";
import { X } from "lucide-react";

interface FilterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onFiltersChange: (filters: FilterOptions) => void;
}

interface FilterOptions {
  schoolTypes: string[];
  boards: string[];
  feeRange: [number, number];
  ratings: number[];
  cities: string[];
}

export function FilterSidebar({ isOpen, onClose, onFiltersChange }: FilterSidebarProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    schoolTypes: [],
    boards: [],
    feeRange: [0, 1000000],
    ratings: [],
    cities: []
  });

  const handleCheckboxChange = (category: keyof FilterOptions, value: string, checked: boolean) => {
    setFilters(prev => {
      const updated = { ...prev };
      if (checked) {
        (updated[category] as string[]).push(value);
      } else {
        const index = (updated[category] as string[]).indexOf(value);
        if (index > -1) {
          (updated[category] as string[]).splice(index, 1);
        }
      }
      return updated;
    });
  };

  const applyFilters = () => {
    onFiltersChange(filters);
    onClose();
  };

  const clearFilters = () => {
    const clearedFilters = {
      schoolTypes: [],
      boards: [],
      feeRange: [0, 1000000] as [number, number],
      ratings: [],
      cities: []
    };
    setFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 md:hidden">
      <div className="fixed right-0 top-0 h-full w-80 bg-background border-l overflow-y-auto">
        <Card className="h-full rounded-none border-0">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Filters</CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* School Type */}
            <div>
              <h4 className="font-medium mb-3">School Type</h4>
              <div className="space-y-2">
                {['Day School', 'Boarding School', 'Boys School', 'Girls School', 'Co-Educational'].map(type => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox
                      id={type}
                      checked={filters.schoolTypes.includes(type)}
                      onCheckedChange={(checked) => handleCheckboxChange('schoolTypes', type, checked as boolean)}
                    />
                    <Label htmlFor={type} className="text-sm">{type}</Label>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Board */}
            <div>
              <h4 className="font-medium mb-3">Board</h4>
              <div className="space-y-2">
                {['CBSE', 'ICSE', 'State Board', 'IB', 'IGCSE'].map(board => (
                  <div key={board} className="flex items-center space-x-2">
                    <Checkbox
                      id={board}
                      checked={filters.boards.includes(board)}
                      onCheckedChange={(checked) => handleCheckboxChange('boards', board, checked as boolean)}
                    />
                    <Label htmlFor={board} className="text-sm">{board}</Label>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Fee Range */}
            <div>
              <h4 className="font-medium mb-3">Annual Fee Range</h4>
              <div className="px-2">
                <Slider
                  value={filters.feeRange}
                  onValueChange={(value) => setFilters(prev => ({ ...prev, feeRange: value as [number, number] }))}
                  max={1000000}
                  step={10000}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-2">
                  <span>₹{filters.feeRange[0].toLocaleString()}</span>
                  <span>₹{filters.feeRange[1].toLocaleString()}</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Rating */}
            <div>
              <h4 className="font-medium mb-3">Minimum Rating</h4>
              <div className="space-y-2">
                {[4, 3, 2, 1].map(rating => (
                  <div key={rating} className="flex items-center space-x-2">
                    <Checkbox
                      id={`rating-${rating}`}
                      checked={filters.ratings.includes(rating)}
                      onCheckedChange={(checked) => handleCheckboxChange('ratings', rating.toString(), checked as boolean)}
                    />
                    <Label htmlFor={`rating-${rating}`} className="text-sm flex items-center">
                      {rating}+ Stars
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {/* Cities */}
            <div>
              <h4 className="font-medium mb-3">City</h4>
              <div className="space-y-2">
                {['Bangalore', 'Mumbai', 'Delhi', 'Pune', 'Chennai', 'Kolkata', 'Hyderabad'].map(city => (
                  <div key={city} className="flex items-center space-x-2">
                    <Checkbox
                      id={city}
                      checked={filters.cities.includes(city)}
                      onCheckedChange={(checked) => handleCheckboxChange('cities', city, checked as boolean)}
                    />
                    <Label htmlFor={city} className="text-sm">{city}</Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={clearFilters} className="flex-1">
                Clear All
              </Button>
              <Button onClick={applyFilters} className="flex-1">
                Apply Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Star, MapPin, Phone, Globe, Users, Award, Calendar, BookOpen, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface School {
  id: number;
  name: string;
  location: string;
  city: string;
  state?: string;
  ranking: number;
  type: string;
  established: number;
  board: string;
  rating: number;
  fees: string;
  students: number;
  phone: string;
  website: string;
  description?: string;
  image?: string;
}

interface EnhancedSchoolCardProps {
  school: School;
  onCompare: (school: School) => void;
  onViewDetails: (school: School) => void;
}

export function EnhancedSchoolCard({ school, onCompare, onViewDetails }: EnhancedSchoolCardProps) {
  const getGradientByRanking = (ranking: number) => {
    if (ranking <= 10) return "from-yellow-400 via-orange-500 to-red-500";
    if (ranking <= 50) return "from-blue-400 via-purple-500 to-pink-500";
    if (ranking <= 100) return "from-emerald-400 via-teal-500 to-blue-500";
    return "from-gray-400 via-gray-500 to-gray-600";
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return "text-green-600";
    if (rating >= 4.0) return "text-blue-600";
    if (rating >= 3.5) return "text-yellow-600";
    return "text-orange-600";
  };

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="h-full"
    >
      <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm h-full flex flex-col">
        <CardContent className="p-0 flex-1 flex flex-col">
          {/* School Image with Overlay */}
          <div className="relative h-48 bg-gradient-to-br from-purple-100 via-blue-100 to-emerald-100 overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-4 left-4 w-16 h-16 border-2 border-purple-300 rounded-full"></div>
              <div className="absolute top-8 right-8 w-12 h-12 border-2 border-blue-300 rounded-lg rotate-45"></div>
              <div className="absolute bottom-6 left-12 w-8 h-8 border-2 border-emerald-300 rounded-full"></div>
            </div>
            
            {/* Ranking Badge */}
            <div className="absolute top-4 right-4 z-10">
              <motion.div
                className={`px-3 py-1 rounded-full bg-gradient-to-r ${getGradientByRanking(school.ranking)} text-white shadow-lg`}
                whileHover={{ scale: 1.1 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <div className="flex items-center gap-1">
                  <Award className="w-3 h-3" />
                  <span className="text-xs font-bold">#{school.ranking}</span>
                </div>
              </motion.div>
            </div>

            {/* Main School Icon */}
            <div className="flex items-center justify-center h-full">
              <motion.div 
                className="text-center"
                animate={{ 
                  rotate: [0, 2, -2, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <div className="text-6xl mb-2 filter drop-shadow-lg">🏫</div>
                <div className="flex items-center justify-center gap-1">
                  <Sparkles className="w-4 h-4 text-purple-500" />
                  <p className="text-sm font-medium text-gray-600">Premium Education</p>
                  <Sparkles className="w-4 h-4 text-blue-500" />
                </div>
              </motion.div>
            </div>
          </div>

          <div className="p-5 flex-1 flex flex-col">
            {/* Header */}
            <div className="mb-4">
              <h3 className="font-bold text-lg text-foreground mb-2 line-clamp-2 leading-tight">{school.name}</h3>
              
              <div className="flex items-center text-sm text-muted-foreground mb-3">
                <MapPin className="w-4 h-4 mr-1 text-red-500" />
                <span>{school.location}, {school.city}{school.state && `, ${school.state}`}</span>
              </div>
              
              {school.description && (
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2 leading-relaxed">
                  {school.description}
                </p>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 text-yellow-500 fill-current" />
                  <span className={`font-bold text-lg ${getRatingColor(school.rating)}`}>{school.rating}</span>
                  <span className="text-sm text-muted-foreground">/5.0</span>
                </div>
                
                <Badge 
                  variant="secondary" 
                  className="bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 border-purple-200"
                >
                  <BookOpen className="w-3 h-3 mr-1" />
                  {school.board}
                </Badge>
              </div>
            </div>

            {/* School Details Grid */}
            <div className="grid grid-cols-2 gap-4 text-sm mb-4 flex-1">
              <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-3">
                <div className="text-muted-foreground mb-1 flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                  Type
                </div>
                <p className="font-medium text-foreground">{school.type}</p>
              </div>
              
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg p-3">
                <div className="text-muted-foreground mb-1 flex items-center">
                  <Calendar className="w-3 h-3 mr-1 text-emerald-500" />
                  Est.
                </div>
                <p className="font-medium text-foreground">{school.established}</p>
              </div>
              
              <div className="bg-gradient-to-br from-orange-50 to-pink-50 rounded-lg p-3 col-span-2">
                <div className="text-muted-foreground mb-1 flex items-center">
                  <Users className="w-3 h-3 mr-1 text-orange-500" />
                  Students Enrolled
                </div>
                <p className="font-medium text-foreground">{school.students.toLocaleString()}+</p>
              </div>
            </div>

            {/* Fees Section */}
            <div className="bg-gradient-to-r from-purple-50 via-blue-50 to-emerald-50 rounded-xl p-4 mb-4 border border-purple-100">
              <div className="text-sm text-muted-foreground mb-1 flex items-center">
                <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full mr-2"></div>
                Annual Fees
              </div>
              <div className="font-bold text-lg bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                {school.fees}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mb-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex-1 border-purple-200 text-purple-700 hover:bg-purple-50 hover:border-purple-300 transition-all duration-300" 
                onClick={() => onCompare(school)}
              >
                Compare
              </Button>
              <Button 
                size="sm" 
                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" 
                onClick={() => onViewDetails(school)}
              >
                View Details
              </Button>
            </div>

            {/* Contact Info */}
            <div className="flex items-center justify-between pt-3 border-t border-gray-100 text-xs">
              <motion.div 
                className="flex items-center text-muted-foreground hover:text-blue-600 transition-colors cursor-pointer"
                whileHover={{ scale: 1.05 }}
              >
                <Phone className="w-3 h-3 mr-1" />
                <span>{school.phone}</span>
              </motion.div>
              
              <motion.div 
                className="flex items-center text-muted-foreground hover:text-emerald-600 transition-colors cursor-pointer"
                whileHover={{ scale: 1.05 }}
              >
                <Globe className="w-3 h-3 mr-1" />
                <span>Website</span>
              </motion.div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
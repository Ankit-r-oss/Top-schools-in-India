interface StatCardProps {
  title: string;
  value: string;
  description: string;
  icon: string;
}

export function StatCard({ title, value, description, icon }: StatCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 text-center">
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-2xl font-medium text-foreground mb-1">{value}</div>
      <h4 className="text-sm font-medium text-foreground mb-1">{title}</h4>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
  );
}
import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Search, BookOpen, Users, Award, TrendingUp } from "lucide-react";
import { motion } from "motion/react";

interface HeroSectionProps {
  onSearch: (query: string, schoolType: string, location: string) => void;
}

export function HeroSection({ onSearch }: HeroSectionProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [schoolType, setSchoolType] = useState("");
  const [location, setLocation] = useState("");

  const handleSearch = () => {
    onSearch(searchQuery, schoolType, location);
  };

  const stats = [
    { icon: BookOpen, value: "1000+", label: "Schools Listed", color: "from-blue-500 to-purple-600" },
    { icon: Users, value: "50K+", label: "Students Helped", color: "from-purple-500 to-pink-600" },
    { icon: Award, value: "95%", label: "Success Rate", color: "from-emerald-500 to-blue-500" },
    { icon: TrendingUp, value: "24/7", label: "Support", color: "from-orange-500 to-red-500" }
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-purple-900 via-blue-900 to-emerald-900 text-white py-16 px-4">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-40 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Left side - Text and Search */}
          <motion.div 
            className="flex-1 text-center lg:text-left"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Find Your 
              <span className="bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-600 bg-clip-text text-transparent block">
                Perfect School
              </span>
            </motion.h1>
            
            <motion.p 
              className="text-blue-100 mb-8 text-lg md:text-xl max-w-2xl mx-auto lg:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Discover top-rated schools across India with our AI-powered search platform. 
              Make informed decisions for your child's bright future! ✨
            </motion.p>

            {/* Search Form */}
            <motion.div 
              className="space-y-4 max-w-2xl mx-auto lg:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select value={schoolType} onValueChange={setSchoolType}>
                  <SelectTrigger className="bg-white/95 backdrop-blur-sm text-foreground border-none shadow-lg hover:shadow-xl transition-shadow">
                    <SelectValue placeholder="🏫 School Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">🌅 Day School</SelectItem>
                    <SelectItem value="boarding">🏠 Boarding School</SelectItem>
                    <SelectItem value="boys">👦 Boys School</SelectItem>
                    <SelectItem value="girls">👧 Girls School</SelectItem>
                    <SelectItem value="co-ed">👫 Co-Educational</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger className="bg-white/95 backdrop-blur-sm text-foreground border-none shadow-lg hover:shadow-xl transition-shadow">
                    <SelectValue placeholder="📍 Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bangalore">🌆 Bangalore</SelectItem>
                    <SelectItem value="mumbai">🏙️ Mumbai</SelectItem>
                    <SelectItem value="delhi">🏛️ Delhi</SelectItem>
                    <SelectItem value="pune">🌱 Pune</SelectItem>
                    <SelectItem value="chennai">🏖️ Chennai</SelectItem>
                    <SelectItem value="kolkata">🎭 Kolkata</SelectItem>
                    <SelectItem value="hyderabad">💎 Hyderabad</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="🔍 Search School Name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white/95 backdrop-blur-sm text-foreground border-none pr-12 shadow-lg hover:shadow-xl transition-all focus:scale-105"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  />
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                </div>
                <Button 
                  onClick={handleSearch} 
                  className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 px-8 shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
                >
                  Search
                </Button>
              </div>
            </motion.div>

            {/* Stats Section */}
            <motion.div 
              className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="text-center p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20"
                  whileHover={{ scale: 1.05, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className={`w-8 h-8 mx-auto mb-2 rounded-lg bg-gradient-to-r ${stat.color} flex items-center justify-center`}>
                    <stat.icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="font-bold text-lg">{stat.value}</div>
                  <div className="text-blue-200 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right side - Enhanced Illustration */}
          <motion.div 
            className="flex-shrink-0"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative">
              {/* Main Illustration */}
              <div className="w-80 h-80 bg-gradient-to-br from-white/10 to-white/5 rounded-3xl flex items-center justify-center backdrop-blur-sm border border-white/20 shadow-2xl">
                <div className="text-center">
                  <motion.div 
                    className="text-8xl mb-4"
                    animate={{ 
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  >
                    🎓
                  </motion.div>
                  <p className="text-blue-100 text-lg font-medium">Educational Excellence</p>
                  <p className="text-blue-200 text-sm">Powered by AI</p>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                className="absolute -top-4 -left-4 w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg"
                animate={{ 
                  y: [0, -10, 0],
                  rotate: [0, 10, 0]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <span className="text-2xl">📚</span>
              </motion.div>

              <motion.div
                className="absolute -bottom-4 -right-4 w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg"
                animate={{ 
                  y: [0, 10, 0],
                  rotate: [0, -10, 0]
                }}
                transition={{ 
                  duration: 2.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1
                }}
              >
                <span className="text-2xl">🌟</span>
              </motion.div>

              <motion.div
                className="absolute top-1/2 -right-8 w-12 h-12 bg-gradient-to-r from-emerald-400 to-blue-500 rounded-xl flex items-center justify-center shadow-lg"
                animate={{ 
                  x: [0, 10, 0],
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5
                }}
              >
                <span className="text-xl">🚀</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
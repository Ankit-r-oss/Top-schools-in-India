import { Badge } from "./ui/badge";

interface RegionData {
  state: string;
  count: number;
  percentage: number;
}

const regionData: RegionData[] = [
  { state: "Maharashtra", count: 45, percentage: 18 },
  { state: "Delhi", count: 38, percentage: 15 },
  { state: "Karnataka", count: 32, percentage: 13 },
  { state: "Tamil Nadu", count: 28, percentage: 11 },
  { state: "Uttar Pradesh", count: 25, percentage: 10 },
  { state: "West Bengal", count: 22, percentage: 9 },
  { state: "Others", count: 60, percentage: 24 },
];

export function RegionalSection() {
  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-xl font-medium text-foreground mb-2">Top Schools by State</h2>
        <p className="text-muted-foreground text-sm">Distribution of top-ranked schools across India</p>
      </div>
      
      <div className="space-y-3">
        {regionData.map((region) => (
          <div key={region.state} className="flex items-center justify-between p-3 bg-card border border-border rounded-lg">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-foreground font-medium">{region.state}</span>
                <Badge variant="secondary" className="text-xs">
                  {region.count} schools
                </Badge>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${region.percentage}%` }}
                />
              </div>
            </div>
            <span className="text-muted-foreground text-sm ml-3">{region.percentage}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
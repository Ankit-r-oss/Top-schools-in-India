import { projectId, publicAnonKey } from '../utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-03ceedfd`;

class ApiService {
  private getHeaders(includeAuth = false) {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    };

    if (includeAuth) {
      const token = localStorage.getItem('supabase.auth.token');
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
    }

    return headers;
  }

  // School related methods
  async getSchools() {
    try {
      const response = await fetch(`${API_BASE_URL}/schools/schools`, {
        headers: this.getHeaders(),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error fetching schools:', error);
      throw error;
    }
  }

  async searchSchools(query: string, filters: any) {
    try {
      const response = await fetch(`${API_BASE_URL}/schools/schools/search`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify({ query, filters }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error searching schools:', error);
      throw error;
    }
  }

  async initializeSchools() {
    try {
      const response = await fetch(`${API_BASE_URL}/schools/schools/init`, {
        method: 'POST',
        headers: this.getHeaders(),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error initializing schools:', error);
      throw error;
    }
  }

  // Authentication methods
  async signUp(email: string, password: string, name: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/signup`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify({ email, password, name }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error signing up:', error);
      throw error;
    }
  }

  async getUserProfile(accessToken: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/profile`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      throw error;
    }
  }

  async saveSchool(schoolId: string, accessToken: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/save-school`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ schoolId }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error saving school:', error);
      throw error;
    }
  }

  // Chat methods
  async sendMessage(message: string, sessionId: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/chat/message`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify({ message, sessionId }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  async getChatHistory(sessionId: string) {
    try {
      const response = await fetch(`${API_BASE_URL}/chat/history/${sessionId}`, {
        headers: this.getHeaders(),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      return data;
    } catch (error) {
      console.error('Error fetching chat history:', error);
      throw error;
    }
  }
}

export const apiService = new ApiService();
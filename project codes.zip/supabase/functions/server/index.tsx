import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Initialize school data
app.get('/make-server-03ceedfd/init-schools', async (c) => {
  try {
    const schools = [
      {
        id: 1,
        name: "The Doon School",
        location: "Dehradun",
        city: "Dehradun",
        state: "Uttarakhand",
        ranking: 1,
        type: "Boys Boarding",
        established: 1935,
        board: "ICSE",
        rating: 4.8,
        fees: "₹7,50,000 - ₹8,50,000",
        students: 500,
        phone: "+91-135-2526400",
        website: "doonschool.com",
        description: "Premier boys boarding school known for academic excellence and leadership development."
      },
      {
        id: 2,
        name: "Bishop Cotton Boys' School",
        location: "Bangalore",
        city: "Bangalore",
        state: "Karnataka",
        ranking: 2,
        type: "Boys Boarding",
        established: 1865,
        board: "ICSE",
        rating: 4.6,
        fees: "₹2,50,000 - ₹4,50,000",
        students: 800,
        phone: "+91-80-25587518",
        website: "bishopschool.org",
        description: "Historic institution focusing on character building and academic achievement."
      },
      {
        id: 3,
        name: "Welham Girls' School",
        location: "Dehradun",
        city: "Dehradun",
        state: "Uttarakhand",
        ranking: 3,
        type: "Girls Boarding",
        established: 1957,
        board: "ICSE",
        rating: 4.7,
        fees: "₹6,00,000 - ₹7,00,000",
        students: 600,
        phone: "+91-135-2672149",
        website: "welhamgirls.org",
        description: "Leading girls boarding school with emphasis on holistic development."
      },
      {
        id: 4,
        name: "Delhi Public School, RK Puram",
        location: "New Delhi",
        city: "Delhi",
        state: "Delhi",
        ranking: 4,
        type: "Co-Educational",
        established: 1972,
        board: "CBSE",
        rating: 4.5,
        fees: "₹1,20,000 - ₹2,50,000",
        students: 3000,
        phone: "+91-11-26174100",
        website: "dpsrkp.net",
        description: "Renowned day school with excellent academic track record."
      },
      {
        id: 5,
        name: "Greenwood High International School",
        location: "Bangalore",
        city: "Bangalore",
        state: "Karnataka",
        ranking: 5,
        type: "Co-Educational",
        established: 2005,
        board: "CBSE",
        rating: 4.4,
        fees: "₹3,00,000 - ₹4,50,000",
        students: 1200,
        phone: "+91-80-28470000",
        website: "greenwoodhigh.edu.in",
        description: "Modern international school with focus on global curriculum."
      },
      {
        id: 6,
        name: "La Martiniere for Boys",
        location: "Kolkata",
        city: "Kolkata",
        state: "West Bengal",
        ranking: 6,
        type: "Boys Day School",
        established: 1836,
        board: "ICSE",
        rating: 4.6,
        fees: "₹80,000 - ₹1,20,000",
        students: 1500,
        phone: "+91-33-22575337",
        website: "lamartiniere.net",
        description: "Historic institution known for academic excellence and sports."
      },
      {
        id: 7,
        name: "Cathedral and John Connon School",
        location: "Mumbai",
        city: "Mumbai",
        state: "Maharashtra",
        ranking: 7,
        type: "Co-Educational",
        established: 1860,
        board: "ICSE",
        rating: 4.5,
        fees: "₹2,00,000 - ₹3,50,000",
        students: 2000,
        phone: "+91-22-22661245",
        website: "cathedral-school.com",
        description: "Premier Mumbai school with strong academic reputation."
      },
      {
        id: 8,
        name: "Sardar Patel Vidyalaya",
        location: "New Delhi",
        city: "Delhi",
        state: "Delhi",
        ranking: 8,
        type: "Co-Educational",
        established: 1973,
        board: "CBSE",
        rating: 4.4,
        fees: "₹1,00,000 - ₹2,00,000",
        students: 2500,
        phone: "+91-11-26115579",
        website: "spvdelhi.com",
        description: "Well-established school with focus on values-based education."
      }
    ];

    // Store schools in KV store
    for (const school of schools) {
      await kv.set(`school:${school.id}`, school);
    }

    await kv.set('schools:all', schools.map(s => s.id));

    return c.json({ 
      message: 'Schools initialized successfully',
      count: schools.length
    });
  } catch (error) {
    console.log('Error initializing schools:', error);
    return c.json({ error: 'Failed to initialize schools' }, 500);
  }
});

// Get all schools
app.get('/make-server-03ceedfd/schools', async (c) => {
  try {
    const schoolIds = await kv.get('schools:all') || [];
    const schools = [];
    
    for (const id of schoolIds) {
      const school = await kv.get(`school:${id}`);
      if (school) schools.push(school);
    }
    
    return c.json({ schools });
  } catch (error) {
    console.log('Error fetching schools:', error);
    return c.json({ error: 'Failed to fetch schools' }, 500);
  }
});

// Search schools
app.post('/make-server-03ceedfd/schools/search', async (c) => {
  try {
    const { query, city, type, board, minRating } = await c.req.json();
    
    const schoolIds = await kv.get('schools:all') || [];
    const schools = [];
    
    for (const id of schoolIds) {
      const school = await kv.get(`school:${id}`);
      if (school) schools.push(school);
    }
    
    let filteredSchools = schools;
    
    if (query) {
      filteredSchools = filteredSchools.filter(school => 
        school.name.toLowerCase().includes(query.toLowerCase()) ||
        school.city.toLowerCase().includes(query.toLowerCase()) ||
        school.location.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    if (city) {
      filteredSchools = filteredSchools.filter(school => 
        school.city.toLowerCase() === city.toLowerCase()
      );
    }
    
    if (type) {
      filteredSchools = filteredSchools.filter(school => 
        school.type.toLowerCase().includes(type.toLowerCase())
      );
    }
    
    if (board) {
      filteredSchools = filteredSchools.filter(school => 
        school.board.toLowerCase() === board.toLowerCase()
      );
    }
    
    if (minRating) {
      filteredSchools = filteredSchools.filter(school => 
        school.rating >= minRating
      );
    }
    
    return c.json({ schools: filteredSchools });
  } catch (error) {
    console.log('Error searching schools:', error);
    return c.json({ error: 'Failed to search schools' }, 500);
  }
});

// Chat endpoint for AI assistant
app.post('/make-server-03ceedfd/chat', async (c) => {
  try {
    const { message, sessionId } = await c.req.json();
    
    // Store user message
    const timestamp = new Date().toISOString();
    const userMessageId = `${sessionId}:${timestamp}:user`;
    await kv.set(`chat:${userMessageId}`, {
      sessionId,
      message,
      isUser: true,
      timestamp
    });
    
    // Generate AI response
    const aiResponse = generateAIResponse(message);
    const aiTimestamp = new Date().toISOString();
    const aiMessageId = `${sessionId}:${aiTimestamp}:ai`;
    await kv.set(`chat:${aiMessageId}`, {
      sessionId,
      message: aiResponse,
      isUser: false,
      timestamp: aiTimestamp
    });
    
    return c.json({ 
      response: aiResponse,
      timestamp: aiTimestamp
    });
  } catch (error) {
    console.log('Error processing chat:', error);
    return c.json({ error: 'Failed to process chat message' }, 500);
  }
});

// Get chat history
app.get('/make-server-03ceedfd/chat/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const messages = await kv.getByPrefix(`chat:${sessionId}:`);
    
    // Sort messages by timestamp
    const sortedMessages = messages.sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    return c.json({ messages: sortedMessages });
  } catch (error) {
    console.log('Error fetching chat history:', error);
    return c.json({ error: 'Failed to fetch chat history' }, 500);
  }
});

function generateAIResponse(userMessage: string): string {
  const message = userMessage.toLowerCase();
  
  if (message.includes('bangalore') || message.includes('bengaluru')) {
    return "Great! Bangalore has excellent schools like Bishop Cotton Boys' School, Greenwood High International School, and many more. These schools offer both day and boarding options. What specific requirements do you have - budget range, board preference (CBSE/ICSE), or co-ed vs single-gender schools?";
  }
  
  if (message.includes('fees') || message.includes('cost') || message.includes('budget')) {
    return "School fees vary significantly based on location and facilities. Day schools typically range from ₹50,000 to ₹3,00,000 annually, while premium boarding schools can go from ₹2,00,000 to ₹8,00,000. Would you like me to suggest schools within a specific budget range?";
  }
  
  if (message.includes('boarding') || message.includes('hostel')) {
    return "Boarding schools are excellent for character development and independence. Top options include The Doon School (Dehradun), Welham Girls' School (Dehradun), and Bishop Cotton Boys' School (Bangalore). Which location and gender preference do you have in mind?";
  }
  
  if (message.includes('cbse') || message.includes('icse') || message.includes('board')) {
    return "Both CBSE and ICSE have unique advantages. CBSE is more widespread with easier transitions and better for competitive exams like JEE/NEET. ICSE offers comprehensive English and analytical thinking skills. Many top schools offer both boards. What's your priority - competitive exam preparation or overall development?";
  }
  
  if (message.includes('delhi') || message.includes('ncr')) {
    return "Delhi NCR has some of India's finest schools including Delhi Public School RK Puram, Sardar Patel Vidyalaya, and Modern School. These schools have excellent academic records and alumni networks. Are you looking for day schools or considering boarding options as well?";
  }
  
  if (message.includes('girls') || message.includes('daughter')) {
    return "For girls' education, we have excellent options like Welham Girls' School (boarding), many DPS branches (co-ed day schools), and Cathedral School Mumbai (co-ed). Would you prefer an all-girls environment or are you open to co-educational schools?";
  }
  
  if (message.includes('boys') || message.includes('son')) {
    return "For boys, top choices include The Doon School and Bishop Cotton Boys' School for boarding, or excellent co-ed day schools like DPS and Greenwood High. Boys-only schools often focus on leadership and character building. What's your preference - single-gender or co-educational environment?";
  }
  
  return "I'm here to help you find the perfect school! Could you share more details about your preferences - location, budget range, day/boarding preference, board type (CBSE/ICSE), or any specific requirements? This will help me suggest the most suitable options for you.";
}

// Health check endpoint
app.get("/make-server-03ceedfd/health", (c) => {
  return c.json({ status: "ok" });
});

Deno.serve(app.fetch);
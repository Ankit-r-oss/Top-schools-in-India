import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Sign up route
app.post('/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured
      email_confirm: true
    });
    
    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }
    
    // Create user profile in KV store
    if (data.user) {
      await kv.set(`user:${data.user.id}`, {
        id: data.user.id,
        email: data.user.email,
        name,
        savedSchools: [],
        searchHistory: [],
        createdAt: new Date().toISOString()
      });
    }
    
    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log('Error in signup:', error);
    return c.json({ error: 'Failed to sign up user' }, 500);
  }
});

// Get user profile
app.get('/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }
    
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: 'Invalid access token' }, 401);
    }
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404);
    }
    
    return c.json({ success: true, profile });
  } catch (error) {
    console.log('Error fetching profile:', error);
    return c.json({ error: 'Failed to fetch profile' }, 500);
  }
});

// Save school to user's favorites
app.post('/save-school', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'No access token provided' }, 401);
    }
    
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      return c.json({ error: 'Invalid access token' }, 401);
    }
    
    const { schoolId } = await c.req.json();
    
    const profile = await kv.get(`user:${user.id}`);
    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404);
    }
    
    const savedSchools = profile.savedSchools || [];
    if (!savedSchools.includes(schoolId)) {
      savedSchools.push(schoolId);
      
      await kv.set(`user:${user.id}`, {
        ...profile,
        savedSchools,
        updatedAt: new Date().toISOString()
      });
    }
    
    return c.json({ success: true, savedSchools });
  } catch (error) {
    console.log('Error saving school:', error);
    return c.json({ error: 'Failed to save school' }, 500);
  }
});

export default app;
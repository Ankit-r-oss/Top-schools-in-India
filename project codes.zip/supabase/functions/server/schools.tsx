import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Get all schools
app.get('/schools', async (c) => {
  try {
    const schools = await kv.getByPrefix('school:');
    return c.json({ success: true, schools });
  } catch (error) {
    console.log('Error fetching schools:', error);
    return c.json({ error: 'Failed to fetch schools' }, 500);
  }
});

// Search schools
app.post('/schools/search', async (c) => {
  try {
    const { query, filters } = await c.req.json();
    
    let schools = await kv.getByPrefix('school:');
    
    // Apply search query
    if (query) {
      schools = schools.filter((school: any) => 
        school.name?.toLowerCase().includes(query.toLowerCase()) ||
        school.location?.toLowerCase().includes(query.toLowerCase()) ||
        school.city?.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    // Apply filters
    if (filters?.cities?.length > 0) {
      schools = schools.filter((school: any) => filters.cities.includes(school.city));
    }
    
    if (filters?.boards?.length > 0) {
      schools = schools.filter((school: any) => filters.boards.includes(school.board));
    }
    
    if (filters?.schoolTypes?.length > 0) {
      schools = schools.filter((school: any) => 
        filters.schoolTypes.some((type: string) => school.type?.includes(type))
      );
    }
    
    return c.json({ success: true, schools });
  } catch (error) {
    console.log('Error searching schools:', error);
    return c.json({ error: 'Failed to search schools' }, 500);
  }
});

// Add new school (admin function)
app.post('/schools', async (c) => {
  try {
    const school = await c.req.json();
    const schoolId = `school:${Date.now()}`;
    
    await kv.set(schoolId, {
      id: schoolId,
      ...school,
      createdAt: new Date().toISOString()
    });
    
    return c.json({ success: true, schoolId });
  } catch (error) {
    console.log('Error adding school:', error);
    return c.json({ error: 'Failed to add school' }, 500);
  }
});

// Initialize sample data
app.post('/schools/init', async (c) => {
  try {
    const sampleSchools = [
      {
        name: "The Doon School",
        location: "Dehradun",
        city: "Dehradun",
        ranking: 1,
        type: "Boys Boarding",
        established: 1935,
        board: "ICSE",
        rating: 4.8,
        fees: "₹7,50,000 - ₹8,50,000",
        students: 500,
        phone: "+91-135-2526400",
        website: "doonschool.com"
      },
      {
        name: "Bishop Cotton Boys' School",
        location: "Bangalore",
        city: "Bangalore",
        ranking: 2,
        type: "Boys Boarding",
        established: 1865,
        board: "ICSE",
        rating: 4.6,
        fees: "₹2,50,000 - ₹4,50,000",
        students: 800,
        phone: "+91-80-25587518",
        website: "bishopschool.org"
      },
      {
        name: "Welham Girls' School",
        location: "Dehradun",
        city: "Dehradun",
        ranking: 3,
        type: "Girls Boarding",
        established: 1957,
        board: "ICSE",
        rating: 4.7,
        fees: "₹6,00,000 - ₹7,00,000",
        students: 600,
        phone: "+91-135-2672149",
        website: "welhamgirls.org"
      },
      {
        name: "Delhi Public School, RK Puram",
        location: "New Delhi",
        city: "Delhi",
        ranking: 4,
        type: "Co-Educational",
        established: 1972,
        board: "CBSE",
        rating: 4.5,
        fees: "₹1,20,000 - ₹2,50,000",
        students: 3000,
        phone: "+91-11-26174100",
        website: "dpsrkp.net"
      },
      {
        name: "Greenwood High International School",
        location: "Bangalore",
        city: "Bangalore",
        ranking: 5,
        type: "Co-Educational",
        established: 2005,
        board: "CBSE",
        rating: 4.4,
        fees: "₹3,00,000 - ₹4,50,000",
        students: 1200,
        phone: "+91-80-28470000",
        website: "greenwoodhigh.edu.in"
      },
      {
        name: "La Martiniere for Boys",
        location: "Kolkata",
        city: "Kolkata",
        ranking: 6,
        type: "Boys Day School",
        established: 1836,
        board: "ICSE",
        rating: 4.6,
        fees: "₹80,000 - ₹1,20,000",
        students: 1500,
        phone: "+91-33-22575337",
        website: "lamartiniere.net"
      }
    ];

    for (const school of sampleSchools) {
      const schoolId = `school:${school.ranking}`;
      await kv.set(schoolId, {
        id: schoolId,
        ...school,
        createdAt: new Date().toISOString()
      });
    }

    return c.json({ success: true, message: 'Sample schools initialized' });
  } catch (error) {
    console.log('Error initializing schools:', error);
    return c.json({ error: 'Failed to initialize schools' }, 500);
  }
});

export default app;
import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Send message to AI assistant
app.post('/message', async (c) => {
  try {
    const { message, sessionId } = await c.req.json();
    
    // Get or create chat session
    let chatSession = await kv.get(`chat:${sessionId}`);
    if (!chatSession) {
      chatSession = {
        id: sessionId,
        messages: [],
        createdAt: new Date().toISOString()
      };
    }
    
    // Add user message
    const userMessage = {
      id: Date.now(),
      text: message,
      isUser: true,
      timestamp: new Date().toISOString()
    };
    
    chatSession.messages.push(userMessage);
    
    // Generate AI response
    const aiResponse = generateAIResponse(message, chatSession.messages);
    const aiMessage = {
      id: Date.now() + 1,
      text: aiResponse,
      isUser: false,
      timestamp: new Date().toISOString()
    };
    
    chatSession.messages.push(aiMessage);
    chatSession.updatedAt = new Date().toISOString();
    
    // Save updated session
    await kv.set(`chat:${sessionId}`, chatSession);
    
    return c.json({ 
      success: true, 
      message: aiMessage,
      sessionId 
    });
  } catch (error) {
    console.log('Error processing message:', error);
    return c.json({ error: 'Failed to process message' }, 500);
  }
});

// Get chat history
app.get('/history/:sessionId', async (c) => {
  try {
    const sessionId = c.req.param('sessionId');
    const chatSession = await kv.get(`chat:${sessionId}`);
    
    if (!chatSession) {
      return c.json({ success: true, messages: [] });
    }
    
    return c.json({ 
      success: true, 
      messages: chatSession.messages 
    });
  } catch (error) {
    console.log('Error fetching chat history:', error);
    return c.json({ error: 'Failed to fetch chat history' }, 500);
  }
});

function generateAIResponse(userInput: string, chatHistory: any[]): string {
  const input = userInput.toLowerCase();
  
  // Context-aware responses based on chat history
  const previousMessages = chatHistory.filter(msg => !msg.isUser).map(msg => msg.text);
  
  if (input.includes('bangalore') || input.includes('bengaluru')) {
    return "Great choice! Bangalore has excellent educational institutions. Based on our database, I'd recommend looking at Bishop Cotton Boys' School (ICSE, ₹2.5-4.5L annually), Greenwood High International School (CBSE, ₹3-4.5L), and several other top-rated schools. What type of school are you looking for - day school or boarding? Also, what's your preferred fee range?";
  }
  
  if (input.includes('fees') || input.includes('cost') || input.includes('price') || input.includes('budget')) {
    return "School fees vary significantly based on location, type, and facilities. In our database:\n\n• Day schools: ₹50,000 to ₹4,50,000 per year\n• Boarding schools: ₹2,00,000 to ₹8,50,000 per year\n• International curriculum: Generally higher fees\n\nCould you tell me your preferred budget range and location? I can show you schools that match your criteria.";
  }
  
  if (input.includes('boarding')) {
    return "Boarding schools offer excellent character development and independence. From our top-rated list:\n\n🏆 The Doon School (Dehradun) - ₹7.5-8.5L\n🏆 Bishop Cotton Boys' School (Bangalore) - ₹2.5-4.5L\n🏆 Welham Girls' School (Dehradun) - ₹6-7L\n\nThese are highly ranked for academics and overall development. Which location would you prefer, and are you looking for co-ed or single-gender schools?";
  }
  
  if (input.includes('cbse') || input.includes('icse') || input.includes('board')) {
    return "Both boards have their strengths:\n\n📚 **CBSE**: More widespread, easier transition for competitive exams like JEE/NEET, standardized across India\n\n📚 **ICSE**: Comprehensive English education, better analytical thinking, more detailed syllabus\n\nMost top schools in our database offer both. Which board are you considering, and what are your child's future academic goals?";
  }
  
  if (input.includes('best') || input.includes('top') || input.includes('recommend')) {
    return "Based on our comprehensive ranking system considering academics, infrastructure, and alumni success, here are some top recommendations:\n\n🥇 National level: The Doon School, Mayo College\n🥈 Metro cities: DPS RK Puram (Delhi), La Martiniere (Kolkata)\n🥉 Bangalore: Bishop Cotton, Greenwood High\n\nTo give you more personalized recommendations, could you share your location preference and any specific requirements?";
  }
  
  if (input.includes('delhi') || input.includes('mumbai') || input.includes('kolkata') || input.includes('chennai')) {
    const city = input.includes('delhi') ? 'Delhi' : 
                 input.includes('mumbai') ? 'Mumbai' :
                 input.includes('kolkata') ? 'Kolkata' : 'Chennai';
    
    return `Excellent choice! ${city} has some outstanding schools. Let me search our database for top-rated schools in ${city}. I can filter by board (CBSE/ICSE), type (day/boarding), and fee range. What specific requirements do you have for your child's education?`;
  }
  
  if (input.includes('compare') || input.includes('difference')) {
    return "I can help you compare schools! Our comparison feature looks at:\n\n• Academic performance & board results\n• Infrastructure & facilities\n• Fee structure & value for money\n• Faculty qualifications\n• Alumni achievements\n• Extra-curricular activities\n\nWhich specific schools would you like me to compare? You can also use our 'Compare Schools' feature on the website.";
  }
  
  return "I'm here to help you find the perfect school for your child! Our database includes detailed information about top schools across India. I can assist you with:\n\n🔍 **School Search** - by location, board, type\n💰 **Fee Information** - budget-friendly options\n📊 **School Comparisons** - detailed analysis\n🎯 **Personalized Recommendations** - based on your needs\n\nWhat specific information are you looking for? Feel free to ask about location, budget, board preference, or any other requirements!";
}

export default app;
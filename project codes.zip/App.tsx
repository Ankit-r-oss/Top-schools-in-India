import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { EnhancedSchoolCard } from "./components/EnhancedSchoolCard";
import { FilterSidebar } from "./components/FilterSidebar";
import { AIAssistant } from "./components/AIAssistant";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Badge } from "./components/ui/badge";
import { Search, Filter, SlidersHorizontal, Loader2, Sparkles, TrendingUp } from "lucide-react";
import { motion } from "motion/react";
import { projectId, publicAnonKey } from './utils/supabase/info';

interface School {
  id: number;
  name: string;
  location: string;
  city: string;
  state?: string;
  ranking: number;
  type: string;
  established: number;
  board: string;
  rating: number;
  fees: string;
  students: number;
  phone: string;
  website: string;
  description?: string;
}

export default function App() {
  const [schools, setSchools] = useState<School[]>([]);
  const [filteredSchools, setFilteredSchools] = useState<School[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize schools data
  useEffect(() => {
    initializeAndFetchSchools();
  }, []);

  const initializeAndFetchSchools = async () => {
    try {
      setLoading(true);
      setError(null);

      // First initialize the schools data
      const initResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-03ceedfd/init-schools`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!initResponse.ok) {
        throw new Error('Failed to initialize schools data');
      }

      // Then fetch all schools
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-03ceedfd/schools`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch schools');
      }

      const data = await response.json();
      setSchools(data.schools);
      setFilteredSchools(data.schools);
    } catch (err) {
      console.error('Error initializing schools:', err);
      setError('Failed to load schools data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (query: string, schoolType: string, location: string) => {
    try {
      setLoading(true);
      setError(null);

      const searchData: any = {};
      if (query) searchData.query = query;
      if (schoolType) searchData.type = schoolType;
      if (location) searchData.city = location;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-03ceedfd/schools/search`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(searchData),
      });

      if (!response.ok) {
        throw new Error('Search failed');
      }

      const data = await response.json();
      setFilteredSchools(data.schools);
      setSearchQuery(query);
    } catch (err) {
      console.error('Search error:', err);
      setError('Search failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFiltersChange = (filters: any) => {
    setActiveFilters(filters);
    let filtered = schools;

    // Apply filters logic here
    if (filters.cities.length > 0) {
      filtered = filtered.filter(school => filters.cities.includes(school.city));
    }

    if (filters.boards.length > 0) {
      filtered = filtered.filter(school => filters.boards.includes(school.board));
    }

    if (filters.schoolTypes.length > 0) {
      filtered = filtered.filter(school => 
        filters.schoolTypes.some((type: string) => school.type.includes(type))
      );
    }

    if (filters.ratings.length > 0) {
      const minRating = Math.min(...filters.ratings);
      filtered = filtered.filter(school => school.rating >= minRating);
    }

    setFilteredSchools(filtered);
  };

  const handleCompare = (school: School) => {
    console.log("Compare school:", school.name);
    // Implement compare functionality
  };

  const handleViewDetails = (school: School) => {
    console.log("View details for:", school.name);
    // Implement view details functionality
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-emerald-50">
      <Header />
      
      <HeroSection onSearch={handleSearch} />

      <div className="max-w-6xl mx-auto p-4 relative">
        {/* Decorative Background Elements */}
        <div className="absolute top-10 left-10 w-32 h-32 bg-purple-200/30 rounded-full blur-3xl"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-blue-200/30 rounded-full blur-3xl"></div>

        {/* Results Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="relative">
            <h2 className="text-3xl font-bold text-foreground mb-2 bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
              {searchQuery ? `Search Results for "${searchQuery}"` : 'Best Schools in India'}
            </h2>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <p className="text-muted-foreground">
                Showing <span className="font-bold text-purple-600">{filteredSchools.length}</span> of <span className="font-bold text-blue-600">{schools.length}</span> schools
              </p>
              <Sparkles className="w-4 h-4 text-yellow-500" />
            </div>
          </div>

          {/* Mobile Filter Button */}
          <Button 
            variant="outline" 
            onClick={() => setIsFilterOpen(true)}
            className="md:hidden border-purple-200 text-purple-700 hover:bg-purple-50 hover:border-purple-300"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </motion.div>

        {/* Active Filters */}
        {Object.keys(activeFilters).length > 0 && (
          <motion.div 
            className="flex flex-wrap gap-2 mb-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {activeFilters.cities?.map((city: string) => (
              <Badge key={city} variant="secondary" className="bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border-blue-200">
                📍 {city}
              </Badge>
            ))}
            {activeFilters.boards?.map((board: string) => (
              <Badge key={board} variant="secondary" className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-700 border-emerald-200">
                📚 {board}
              </Badge>
            ))}
            {activeFilters.schoolTypes?.map((type: string) => (
              <Badge key={type} variant="secondary" className="bg-gradient-to-r from-orange-100 to-pink-100 text-orange-700 border-orange-200">
                🏫 {type}
              </Badge>
            ))}
          </motion.div>
        )}

        <div className="flex gap-6">
          {/* Desktop Filter Sidebar */}
          <div className="hidden md:block w-80 flex-shrink-0">
            <div className="sticky top-4">
              <motion.div 
                className="bg-white/80 backdrop-blur-sm border border-purple-100 rounded-2xl p-6 shadow-xl"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                    <SlidersHorizontal className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="font-bold text-lg bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">Filters</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="🔍 Quick search..."
                      className="pr-12 bg-white/50 border-purple-200 focus:border-purple-400 rounded-xl"
                    />
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-purple-400" />
                  </div>
                  
                  <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-100">
                    <div className="text-center">
                      <div className="text-2xl mb-2">🎯</div>
                      <div className="text-sm font-medium text-purple-700 mb-1">Smart Filtering</div>
                      <div className="text-xs text-muted-foreground">
                        Use the mobile filter for advanced options or let our AI assistant help you find the perfect school!
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Schools Grid */}
          <div className="flex-1">
            {loading ? (
              <motion.div 
                className="flex items-center justify-center py-20"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                <div className="text-center">
                  <div className="relative mb-4">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto">
                      <Loader2 className="w-8 h-8 animate-spin text-white" />
                    </div>
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-pulse"></div>
                  </div>
                  <h3 className="font-bold text-lg text-foreground mb-2">Loading Amazing Schools...</h3>
                  <p className="text-muted-foreground">Finding the best educational institutions for you ✨</p>
                </div>
              </motion.div>
            ) : error ? (
              <motion.div 
                className="text-center py-20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="text-8xl mb-6">😔</div>
                <h3 className="text-2xl font-bold text-foreground mb-3">Oops! Something went wrong</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">{error}</p>
                <Button 
                  onClick={initializeAndFetchSchools}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  Try Again
                </Button>
              </motion.div>
            ) : (
              <>
                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6, staggerChildren: 0.1 }}
                >
                  {filteredSchools.map((school, index) => (
                    <motion.div
                      key={school.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <EnhancedSchoolCard
                        school={school}
                        onCompare={handleCompare}
                        onViewDetails={handleViewDetails}
                      />
                    </motion.div>
                  ))}
                </motion.div>

                {filteredSchools.length === 0 && !loading && (
                  <motion.div 
                    className="text-center py-20"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <div className="text-8xl mb-6">🔍</div>
                    <h3 className="text-2xl font-bold text-foreground mb-3">No schools found</h3>
                    <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                      We couldn't find any schools matching your criteria. Try adjusting your search or filters.
                    </p>
                    <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                      <Sparkles className="w-4 h-4 text-purple-500" />
                      <span>Pro tip: Use our AI assistant for personalized recommendations!</span>
                      <Sparkles className="w-4 h-4 text-blue-500" />
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filter Sidebar */}
      <FilterSidebar
        isOpen={isFilterOpen}
        onClose={() => setIsFilterOpen(false)}
        onFiltersChange={handleFiltersChange}
      />

      {/* AI Assistant */}
      <AIAssistant
        isOpen={isChatOpen}
        onToggle={() => setIsChatOpen(!isChatOpen)}
      />
    </div>
  );
}